const canvas = document.getElementById('game-canvas');
const ctx = canvas.getContext('2d');

const loadingScreen = document.getElementById('loading-screen');
const gameContainer = document.getElementById('game-container');
const scoreDisplay = document.getElementById('score');

const ASSETS_PATH = 'asset/';
const SOUND_PATH = ASSETS_PATH + 'sound/';
const IMAGE_PATH = ASSETS_PATH + 'image/';

const sounds = {
  intro: new Audio(SOUND_PATH + 'game-intro-345507.mp3'),
  start: new Audio(SOUND_PATH + 'game-start-6104.mp3'),
  point: new Audio(SOUND_PATH + 'collect-points-190037.mp3'),
  bomb: new Audio(SOUND_PATH + 'bomb-2-360875.mp3'),
  gameOver: new Audio(SOUND_PATH + 'game-over-160612.mp3'),
};

// Set volume for all sounds to max (1.0)
sounds.intro.volume = 1.0;
sounds.start.volume = 1.0;
sounds.point.volume = 1.0;
sounds.bomb.volume = 1.0;
sounds.gameOver.volume = 1.0;

const images = {
  mango: new Image(),
  strawberry: new Image(),
  peach: new Image(),
  orange: new Image(),
  bomb: new Image(),
  blast: new Image(),
};

images.mango.src = IMAGE_PATH + 'mango.png';
images.strawberry.src = IMAGE_PATH + 'stawberry.png';
images.peach.src = IMAGE_PATH + 'peach.png';
images.orange.src = IMAGE_PATH + 'orange.png';
images.bomb.src = IMAGE_PATH + 'bomb.png';
images.blast.src = IMAGE_PATH + 'blust.png';

// Game variables
let canvasWidth, canvasHeight;
let gridSize = 40; // increased size of one snack segment and fruit/bomb for better visibility
let snack = [];
let direction = { x: 1, y: 0 };
let nextDirection = { x: 1, y: 0 };
let fruits = [];
let bomb = null;
let score = 0;
let gameOver = false;
let gameStarted = false;
let spawnFruitInterval;
let spawnBombTimeout;
let snackSpeed = 150; // ms per move
let moveInterval;
let blastTimeout;

// Responsive canvas size
function resizeCanvas() {
  canvasWidth = gameContainer.clientWidth;
  canvasHeight = gameContainer.clientHeight;
  canvas.width = canvasWidth - (canvasWidth % gridSize);
  canvas.height = canvasHeight - (canvasHeight % gridSize);
}
window.addEventListener('resize', resizeCanvas);

// Initialize snack in center
function initSnack() {
  snack = [
    { x: Math.floor(canvas.width / (2 * gridSize)), y: Math.floor(canvas.height / (2 * gridSize)) },
  ];
  direction = { x: 1, y: 0 };
  nextDirection = { x: 1, y: 0 };
}

// Spawn a fruit randomly
function spawnFruit() {
  if (gameOver) return;
  const MAX_FRUITS = 5;
  if (fruits.length >= MAX_FRUITS) return; // limit max fruits on screen
  const fruitTypes = ['mango', 'strawberry', 'peach', 'orange'];
  const type = fruitTypes[Math.floor(Math.random() * fruitTypes.length)];
  const position = getRandomPosition();
  fruits.push({ type, x: position.x, y: position.y, life: 20 + Math.floor(Math.random() * 10) }); // life in moves
}

// Spawn bomb sometimes
function spawnBomb() {
  if (gameOver) return;
  if (bomb) return; // only one bomb at a time
  const position = getRandomPosition();
  bomb = { x: position.x, y: position.y, life: 30 }; // life in moves (~4s)
  // Schedule bomb removal after life ends
  spawnBombTimeout = setTimeout(() => {
    bomb = null;
  }, 4000);
}

// Get random position on grid not occupied by snack or fruits or bomb
function getRandomPosition() {
  let position;
  let collision;
  do {
    position = {
      x: Math.floor(Math.random() * (canvas.width / gridSize)),
      y: Math.floor(Math.random() * (canvas.height / gridSize)),
    };
    collision = snack.some(seg => seg.x === position.x && seg.y === position.y) ||
      fruits.some(f => f.x === position.x && f.y === position.y) ||
      (bomb && bomb.x === position.x && bomb.y === position.y);
  } while (collision);
  return position;
}

// Draw functions
function drawSnack() {
  if (snack.length < 2) {
    // Draw a simple circle if only one segment
    const head = snack[0];
    const x = head.x * gridSize + gridSize / 2;
    const y = head.y * gridSize + gridSize / 2;
    const radius = gridSize / 2 * 0.8;

    ctx.fillStyle = '#0000ff'; // blue color
    ctx.shadowColor = 'rgba(0, 0, 255, 0.7)';
    ctx.shadowBlur = 8;

    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();

    drawHead(x, y);
    return;
  }

  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  ctx.strokeStyle = '#0000ff'; // blue color
  ctx.lineWidth = gridSize * 0.8;
  ctx.shadowColor = 'rgba(0, 0, 255, 0.7)';
  ctx.shadowBlur = 8;

  ctx.beginPath();
  for (let i = 0; i < snack.length; i++) {
    const segment = snack[i];
    const x = segment.x * gridSize + gridSize / 2;
    const y = segment.y * gridSize + gridSize / 2;
    if (i === 0) {
      ctx.moveTo(x, y);
    } else {
      ctx.lineTo(x, y);
    }
  }
  ctx.stroke();

  // Draw head
  const head = snack[0];
  const headX = head.x * gridSize + gridSize / 2;
  const headY = head.y * gridSize + gridSize / 2;
  drawHead(headX, headY);
}

function drawHead(x, y) {
  const eyeRadius = gridSize * 0.1;
  const pupilRadius = eyeRadius * 0.5;
  const eyeOffsetX = gridSize * 0.2;
  const eyeOffsetY = gridSize * 0.15;
  const mouthWidth = gridSize * 0.3;
  const mouthHeight = gridSize * 0.15;

  // Draw head circle
  ctx.fillStyle = '#0000ff';
  ctx.shadowColor = 'rgba(0, 0, 255, 0.7)';
  ctx.shadowBlur = 8;
  ctx.beginPath();
  ctx.arc(x, y, gridSize * 0.4, 0, Math.PI * 2);
  ctx.fill();

  // Draw eyes
  // Left eye white
  ctx.beginPath();
  ctx.fillStyle = 'white';
  ctx.shadowBlur = 0;
  ctx.arc(x - eyeOffsetX, y - eyeOffsetY, eyeRadius, 0, Math.PI * 2);
  ctx.fill();

  // Left pupil black
  ctx.beginPath();
  ctx.fillStyle = 'black';
  ctx.arc(x - eyeOffsetX, y - eyeOffsetY, pupilRadius, 0, Math.PI * 2);
  ctx.fill();

  // Right eye white
  ctx.beginPath();
  ctx.fillStyle = 'white';
  ctx.arc(x + eyeOffsetX, y - eyeOffsetY, eyeRadius, 0, Math.PI * 2);
  ctx.fill();

  // Right pupil black
  ctx.beginPath();
  ctx.fillStyle = 'black';
  ctx.arc(x + eyeOffsetX, y - eyeOffsetY, pupilRadius, 0, Math.PI * 2);
  ctx.fill();

  // Draw smiling mouth
  ctx.beginPath();
  ctx.strokeStyle = 'white';
  ctx.lineWidth = 2;
  ctx.shadowBlur = 0;
  ctx.moveTo(x - mouthWidth / 2, y + mouthHeight / 2);
  ctx.quadraticCurveTo(x, y + mouthHeight, x + mouthWidth / 2, y + mouthHeight / 2);
  ctx.stroke();
}

function drawFruits() {
  const size = gridSize * 1.5;
  fruits.forEach(fruit => {
    const img = images[fruit.type];
    const offset = (size - gridSize) / 2;
    ctx.drawImage(img, fruit.x * gridSize - offset, fruit.y * gridSize - offset, size, size);
  });
}

function drawBomb() {
  if (bomb) {
    const size = gridSize * 1.5;
    const offset = (size - gridSize) / 2;
    ctx.drawImage(images.bomb, bomb.x * gridSize - offset, bomb.y * gridSize - offset, size, size);
  }
}

// Clear canvas
function clearCanvas() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
}

// Update game state
function update() {
  if (gameOver) return;

  // Update direction
  direction = nextDirection;

  // Calculate new head position
  const head = { x: snack[0].x + direction.x, y: snack[0].y + direction.y };

  // Wrap around edges
  if (head.x < 0) head.x = canvas.width / gridSize - 1;
  else if (head.x >= canvas.width / gridSize) head.x = 0;
  if (head.y < 0) head.y = canvas.height / gridSize - 1;
  else if (head.y >= canvas.height / gridSize) head.y = 0;

  // Check collision with self
  if (snack.some(seg => seg.x === head.x && seg.y === head.y)) {
    endGame();
    return;
  }

// Add endGame function to handle game over on self collision
function endGame() {
  gameOver = true;
  sounds.bomb.play();
  showBlast(snack[0].x, snack[0].y);
  setTimeout(() => {
    sounds.gameOver.play();
  }, 500);
  clearInterval(moveInterval);
  clearInterval(spawnFruitInterval);
  clearTimeout(spawnBombTimeout);
  setTimeout(() => {
    alert('Game Over! Your score: ' + score);
    resetGame();
  }, 1500);
}

  // Check collision with bomb
  if (bomb && head.x === bomb.x && head.y === bomb.y) {
    eatBomb();
    return;
  }

  // Check collision with fruits
  const fruitIndex = fruits.findIndex(f => f.x === head.x && f.y === head.y);
  if (fruitIndex !== -1) {
    eatFruit(fruitIndex);
  } else {
    // Move snack: remove tail
    snack.pop();
  }

  // Add new head
  snack.unshift(head);

  // Decrease life of fruits and remove expired
  fruits.forEach(fruit => fruit.life--);
  fruits = fruits.filter(fruit => fruit.life > 0);

  // Decrease bomb life
  if (bomb) {
    bomb.life--;
    if (bomb.life <= 0) {
      bomb = null;
    }
  }
}

// Eat fruit
function eatFruit(index) {
  const fruit = fruits[index];
  fruits.splice(index, 1);
  score++;
  scoreDisplay.textContent = 'Score: ' + score;
  sounds.point.play();
  // Grow snack by not removing tail this move

  // Increase difficulty after score reaches 10
  if (score === 10) {
    // Increase snack speed (reduce interval time)
    snackSpeed = Math.max(50, snackSpeed - 50); // increase speed, min 50ms
    clearInterval(moveInterval);
    moveInterval = setInterval(gameLoop, snackSpeed);

    // Increase bomb spawn frequency by clearing and resetting interval
    clearInterval(spawnBombInterval);
    spawnBombInterval = setInterval(() => {
      if (!gameOver && Math.random() < 0.6) { // higher chance
        spawnBomb();
      }
    }, 3000);
  }
}

// Eat bomb
function eatBomb() {
  gameOver = true;
  sounds.bomb.play();
  showBlast(snack[0].x, snack[0].y);
  setTimeout(() => {
    sounds.gameOver.play();
  }, 500);
  clearInterval(moveInterval);
  clearInterval(spawnFruitInterval);
  clearTimeout(spawnBombTimeout);

  // Show game over overlay instead of alert
  showGameOverOverlay();
}

// Show game over overlay
function showGameOverOverlay() {
  console.log('Showing game over overlay');
  const overlay = document.getElementById('game-over-overlay');
  if (overlay) {
    overlay.classList.remove('hidden');
    overlay.style.display = 'flex'; // ensure visible
  } else {
    console.error('Game over overlay element not found');
  }
}

// Hide game over overlay
function hideGameOverOverlay() {
  console.log('Hiding game over overlay');
  const overlay = document.getElementById('game-over-overlay');
  if (overlay) {
    overlay.classList.add('hidden');
    overlay.style.display = 'none'; // ensure hidden
  } else {
    console.error('Game over overlay element not found');
  }
}

// Reset game
function resetGame() {
  hideGameOverOverlay();
  gameOver = false;
  score = 0;
  scoreDisplay.textContent = 'Score: 0';
  fruits = [];
  bomb = null;
  initSnack();
  startGame();
}

// Show blast image at position
function showBlast(x, y) {
  const blastImg = document.createElement('img');
  blastImg.src = images.blast.src;
  blastImg.className = 'blast-image';
  blastImg.style.left = x * gridSize + 'px';
  blastImg.style.top = y * gridSize + 'px';
  gameContainer.appendChild(blastImg);
  setTimeout(() => {
    gameContainer.removeChild(blastImg);
  }, 1000);
}

// Draw everything
function draw() {
  clearCanvas();
  drawFruits();
  drawBomb();
  drawSnack();
}

// Game loop
function gameLoop() {
  update();
  draw();
}

// Remove keyboard and touch controls for movement as snack will follow cursor

// New variables for cursor position
let cursorGridX = null;
let cursorGridY = null;

// New variable for target fruit position on touch
let targetFruitPos = null;

// Mouse move event to update cursor position in grid coordinates
function handleMouseMove(e) {
  const rect = canvas.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;
  cursorGridX = Math.floor(x / gridSize);
  cursorGridY = Math.floor(y / gridSize);
}

// Touch event to handle tap on fruit
function handleTouchEnd(e) {
  if (gameOver) return;
  const touch = e.changedTouches[0];
  const rect = canvas.getBoundingClientRect();
  const x = touch.clientX - rect.left;
  const y = touch.clientY - rect.top;
  const gridX = Math.floor(x / gridSize);
  const gridY = Math.floor(y / gridSize);

  console.log('Touch end at grid:', gridX, gridY);

  // Find fruit at tapped position or nearest fruit within 1 grid distance
  let nearestFruit = null;
  let minDist = Infinity;
  fruits.forEach(fruit => {
    const dist = Math.abs(fruit.x - gridX) + Math.abs(fruit.y - gridY);
    if (dist <= 1 && dist < minDist) {
      nearestFruit = fruit;
      minDist = dist;
    }
  });

  if (nearestFruit) {
    targetFruitPos = { x: nearestFruit.x, y: nearestFruit.y };
    console.log('Target fruit set at:', targetFruitPos);
  }
}

// Update function modified to move snack head towards cursor or target fruit position
function update() {
  if (gameOver) return;

  let moveTargetX = cursorGridX;
  let moveTargetY = cursorGridY;

  if (targetFruitPos) {
    moveTargetX = targetFruitPos.x;
    moveTargetY = targetFruitPos.y;

    // If snack head reached target fruit position, clear target
    const head = snack[0];
    if (head.x === targetFruitPos.x && head.y === targetFruitPos.y) {
      targetFruitPos = null;
    }
  }

  if (moveTargetX === null || moveTargetY === null) {
    // If no target position, keep current direction
    direction = nextDirection;
  } else {
    const head = snack[0];
    let dx = moveTargetX - head.x;
    let dy = moveTargetY - head.y;

    // Normalize movement to one step in x or y direction
    if (dx !== 0) dx = dx / Math.abs(dx);
    if (dy !== 0) dy = dy / Math.abs(dy);

    // Prioritize horizontal or vertical movement based on distance
    if (Math.abs(moveTargetX - head.x) > Math.abs(moveTargetY - head.y)) {
      direction = { x: dx, y: 0 };
    } else {
      direction = { x: 0, y: dy };
    }
  }

  // Calculate new head position
  const head = { x: snack[0].x + direction.x, y: snack[0].y + direction.y };

  // Wrap around edges
  if (head.x < 0) head.x = canvas.width / gridSize - 1;
  else if (head.x >= canvas.width / gridSize) head.x = 0;
  if (head.y < 0) head.y = canvas.height / gridSize - 1;
  else if (head.y >= canvas.height / gridSize) head.y = 0;

  // Check collision with self
  if (snack.some(seg => seg.x === head.x && seg.y === head.y)) {
    endGame();
    return;
  }

  // Check collision with bomb
  if (bomb && head.x === bomb.x && head.y === bomb.y) {
    eatBomb();
    return;
  }

  // Check collision with fruits
  const fruitIndex = fruits.findIndex(f => f.x === head.x && f.y === head.y);
  if (fruitIndex !== -1) {
    eatFruit(fruitIndex);
  } else {
    // Move snack: remove tail
    snack.pop();
  }

  // Add new head
  snack.unshift(head);

  // Decrease life of fruits and remove expired
  fruits.forEach(fruit => fruit.life--);
  fruits = fruits.filter(fruit => fruit.life > 0);

  // Decrease bomb life
  if (bomb) {
    bomb.life--;
    if (bomb.life <= 0) {
      bomb = null;
    }
  }
}

// Reset game
function resetGame() {
  gameOver = false;
  score = 0;
  scoreDisplay.textContent = 'Score: 0';
  fruits = [];
  bomb = null;
  initSnack();
  startGame();
}

// Start game
function startGame() {
  gameStarted = true;
  loadingScreen.classList.add('hidden');
  gameContainer.classList.remove('hidden');
  hideGameOverOverlay();  // Hide overlay on game start
  resizeCanvas();
  initSnack();
  sounds.intro.play();
  setTimeout(() => {
    sounds.start.play();
    moveInterval = setInterval(gameLoop, snackSpeed);
    spawnFruitInterval = setInterval(spawnFruit, 2000);
    spawnBomb();
    setInterval(() => {
      if (!gameOver && Math.random() < 0.3) {
        spawnBomb();
      }
    }, 5000);
  }, 3000);
}

// Initial loading screen timer
window.onload = () => {
  hideGameOverOverlay(); // Ensure overlay hidden on page load
  setTimeout(() => {
    startGame();
  }, 3000);
};

window.addEventListener('mousemove', handleMouseMove);
canvas.addEventListener('touchend', handleTouchEnd);

// Add event listener for restart button
document.getElementById('restart-button').addEventListener('click', () => {
  resetGame();
});

// Remove keyboard and touch event listeners as snack follows cursor
// window.addEventListener('keydown', handleKey);
// window.addEventListener('touchstart', handleTouchStart);
// window.addEventListener('touchmove', handleTouchMove);
